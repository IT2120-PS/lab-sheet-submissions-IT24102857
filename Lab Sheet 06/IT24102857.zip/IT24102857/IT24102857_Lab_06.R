setwd("C:\\Users\\M S I\\Desktop\\PS Lab_06\\IT24102857")
getwd()

#Exercise
#Question 01

#part 01
#Binomial Distribution
#Here,random variable X has binomial distribution with n=50 and p=0.85

#part 02
pbinom(46,50,0.85,lower.tail=FALSE)


#Question 02
#Part 01
#The number of customer calls received in one hour at the call center

#Part 02
#Poisson distribution
#Here, random variable X has poisson distribution with lamda=12

#Part 03
dpois(15,12)
