setwd("C:\\Users\\M S I\\Desktop\\PS Lab\\IT24102857")
getwd()

#01 
Delivery_Times <- read.table("Exercise - Lab 05.txt", header=TRUE)
names(Delivery_Times) <- "Time"
times <- as.numeric(Delivery_Times$Time)

#02 
breaks <- seq(20, 70, length.out = 10)
hist(times, breaks = breaks, right = FALSE, main = "HIstogram for Delivery Times", 
     xlab = "Delivery time", ylab = "Frequency",col = "lightblue")

#03
#The histogram shows a roughly symmetric distribution with a slight right skew. 
#Most delivery times fall between 30 and 50 minutes.
#There are fewer observations above 60 minutes.

#04
hist_data <- hist(times, breaks = breaks, plot = FALSE, right = FALSE)
midpoints <- hist_data$mids
cum_freq <- cumsum(hist_data$counts)

upper_bounds <- hist_data$breaks[-1]   # exclude first (lower) break
plot(upper_bounds, cum_freq, type = "o",
     main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Time",
     ylab = "Cumulative Frequency")





